"""
psuitls: a sample python module
"""
import os
from pprint import pprint
import json

name = 'hp'
city = 'bangalore'
version = 0.1


def ls(path='.'):
    """
    ls() list the directory content
    :param path: string
    :return: None
    """
    for item in os.listdir(path):
        print item

def power(x, n):
    """
    power(x, n), raises x to the power of n
    :param x: int
    :param n: int
    :return: int
    """
    return x ** n


class ParseJSON(object):
    """
    PraseJSON, parses the json content
    """
    def __init__(self, json_file):
        """
        :param json_file: json filename
        :return:
        """
        self.json_file = json_file
        self.content = json.load(open(json_file))

    def dump_content(self):
        """
        dump_content(), dump python datastruct from the json string
        :return:
        """
        pprint(self.content)


def main():
    print name
    print power(2, 3)
    p = ParseJSON('testit.json')
    p.dump_content()

if __name__ == '__main__':
    main()