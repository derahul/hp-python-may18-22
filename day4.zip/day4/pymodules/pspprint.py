print 123
