__author__ = 'ravi'

from psutils import ParseJSON, ls
from sys import argv

p = ParseJSON(argv[1])
p.dump_content()

ls('.')
