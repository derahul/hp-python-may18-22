__author__ = 'ravi'

class RangeError(Exception):
    def __str__(self):
        return "{}: {}".format(self.__class__.__name__, self.message)

def check_radiation(radiation):
    if radiation > 0.4:
        raise RangeError('radiation is far too high: {} '.format(radiation))


try:
    check_radiation(0.7)
except RangeError, e:
    print e