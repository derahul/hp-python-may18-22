__author__ = 'ravi'
from sys import argv, exc_info
import traceback

def safe_float(value):
    try:
        result = None
        result = float(value[1]) / 0
    except ValueError, e:
        print e
    except (IndexError, KeyError), e:
        print e
    except:
       print exc_info()
       print "-" * 10
       print traceback.print_tb(exc_info()[-1])
       print "-" * 10
       print traceback.print_stack()
        #print "internal server error"
    finally:
        return result

print safe_float(argv)