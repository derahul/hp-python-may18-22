__author__ = 'ravi'
from getpass import getpass

ps = getpass('Enter the password :')
print ps
