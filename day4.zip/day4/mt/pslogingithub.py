__author__ = 'ravi'
import requests
from getpass import  getpass
urls = {
            'http': 'http://web-proxy.ind.hp.com:8080',
              'https': 'http://web-proxy.ind.hp.com:8080',
              }

r = requests.get('https://api.github.com/user',
                 auth=('ravijaya', getpass()),
                 verify=False,
                 proxies=urls)

if r.status_code == 200:
    print r.headers.get('content-type')
    response = r.json()

else:
    print r.status_code
    print r.headers.get('content-type')
    response = r.json()

for item in response:
    print "{} : {}".format(item, response[item])