__author__ = 'ravi'
from pprint import pprint
import requests
r = requests.get('http://home.hp.com')

if r.status_code == 200:
    for header in r.headers:
        print "{} : {}".format(header, r.headers.get(header))

    print r.text

