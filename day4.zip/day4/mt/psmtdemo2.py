__author__ = 'ravi'
import logging
from time import sleep
from random import randint
import threading

logging.basicConfig(level=logging.DEBUG,
                        format="%(threadName)s: %(message)s")

def worker(delay, thread_lock):
    name = threading.currentThread().getName()
    logging.debug("waits for the lock")
    with thread_lock:
        logging.debug("acquired lock")
        sleep(delay)
        print "worker thread : {}".format(name)
        logging.debug("released lock")

lock = threading.Lock()

for i in range(1, 6):
    t = threading.Thread(target=worker,
                         name='t'+str(i), args=(1, lock))
    t.start()

for t in threading.enumerate():
    if t is not threading.currentThread():
        t.join()
        #print t
print "{}: thread ends".format(threading.currentThread().getName())