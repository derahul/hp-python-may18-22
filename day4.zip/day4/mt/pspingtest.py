__author__ = 'ravi'
import logging
import threading
import ping
from sys import argv
from time import time, sleep
logging.basicConfig(level=logging.DEBUG,
                    format="%(threadName)s:%(message)s")

def test_host(hostname):

    if ping.quiet_ping(hostname, count=1)[0] == 100:
        mesg = "{} : down".format(hostname)
    else:
        mesg = "{} : up".format(hostname)

    logging.debug("waiting to print")
    with semp:
        threads.append(threading.currentThread().getName())
        logging.debug("ready to print: {}".format(threads))

        with lock:
            print mesg

    threads.remove(threading.currentThread().getName())

lock = threading.Lock()
semp = threading.Semaphore(3)
threads = []
start = time()
for hostname in open(argv[1]):
    t = threading.Thread(target=test_host, name=hostname.rstrip(),
                         args=(hostname.rstrip(),))
    t.start()

for t in threading.enumerate():
    if t is not threading.currentThread():
        t.join()

end = time()

print "{} seconds".format(end - start)