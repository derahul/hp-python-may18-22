__author__ = 'ravi'
from time import sleep
from random import randint
import threading

def worker(delay):
    name = threading.currentThread().getName()

    print "{}: waits for : {}".format(name, delay)
    sleep(delay)
    #print threading.currentThread().ident
    print "worker thread : {}".format(name)


threads = []

for i in range(1, 6):
    t = threading.Thread(target=worker,
                         name='t'+str(i), args=(randint(0, 3),))
    t.start()
    threads.append(t)

for t in threads:
    t.join

print "{}: thread ends".format(threading.currentThread().getName())