__author__ = 'ravi'
import logging

logging.basicConfig(level=logging.INFO, filename='/tmp/test.log',
    format="%(asctime)s [%(process)d] %(levelname)s:%(message)s")

logging.debug('a debug note')
logging.info('a note of information')
logging.warn('warnings')
logging.error('error message')
logging.critical('critical error')