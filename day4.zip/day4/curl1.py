#!/usr/bin/env python
import urllib2
import json
import os

os.environ['HTTP_PROXY'] = 'https://web-proxy.ind.hp.com:8080'
os.environ['HTTPS_PROXY'] = 'https://web-proxy.ind.hp.com:8080'

url = r'http://graph.facebook.com/1157251270'
response = urllib2.urlopen(url)

#print response.info()
#print response.info()['ETag']

info = json.loads(response.read())

for k in info:
    print "[{}] -> {}".format(k, info.get(k))
    
response.close()
