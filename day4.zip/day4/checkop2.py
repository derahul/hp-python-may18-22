#!/usr/bin/env python

import subprocess

op = \
 subprocess.check_output('cat -n /etc/passwd', shell=True)

print op.rstrip()

