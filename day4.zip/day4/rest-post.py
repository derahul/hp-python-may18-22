#!/usr/bin/env python
import urllib2
import urllib
import json

# post method
query = {'area': 'bayview', 'zip' : '56123'}

url = 'http://localhost/accept.php'
data = urllib.urlencode(query)

r = urllib2.Request(url, data)
res = urllib2.urlopen(r)
js = res.read()

info = json.loads(js)

for k in info:
    print "{} : {}".format(k, info.get(k))



