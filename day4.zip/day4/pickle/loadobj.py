#!/usr/bin/env python
import pprint
import pickle

data = None
with open('info.dat', 'r') as fp:
    data = pickle.load(fp)  #searlize
pprint.pprint(data)

