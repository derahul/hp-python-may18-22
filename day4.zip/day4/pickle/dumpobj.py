#!/usr/bin/env python
from pprint import pprint
import pickle

data = {'name' : 'jackson', 'profile':['actor', 'director'], 'interest' : ['read', 'swim', 'walk', {'data1' : 1, 'data2': 2}] }
with open('info.dat', 'w') as fp:
    pickle.dump(data, fp)  #searlize

pprint(data)
