#!/usr/bin/env python

import re
import sys

with open(sys.argv[1], 'r') as fp:
    with open(sys.argv[2], 'w') as fw:
        for line in fp:
             fw.write( re.sub(r'([0-9]{2})-([0-9]{2})-([0-9]{4})',            r'\3-\1-\2', line ) )


