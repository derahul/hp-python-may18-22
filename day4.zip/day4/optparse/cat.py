#!/usr/bin/env python
import optparse

class Cat(object):
    def __init__(self):
        self._handle_options()
        if self.options.r:
            self._tac_ln()
        else:
            self._cat_ln()

        
    def readlines(self):
        for filename  in  self.args:
            for i, l in enumerate(open(filename), 1):
                yield i, l    
    
    def revreadlines(self):
        for filename  in  self.args:
            for i, l in \
               enumerate(open(filename).readlines()[::-1], 1):
                yield i, l    

    def _handle_options(self):
        parser = optparse.OptionParser(
            usage='%prog [options] <arg1> <arg2> [<arg3>...]',
            prog='cat',
        )
        parser.add_option('-n', action="store_true", 
            default=False)
        parser.add_option('-r', action="store_true", 
        default=False)

        self.options, self.args =  parser.parse_args()

    def _cat_ln(self):
        for ln, line in self.readlines():
            if self.options.n:
                print "{:>6}  {}".format(ln, line.rstrip())
            else: 
                print "{}".format(line.rstrip())

    def _tac_ln(self):
        if self.options.n:
            s = '"{:>6}  {}".format(ln, line.rstrip())'
        else: 
            s = '"{}".format(line.rstrip())'

        for ln, line in self.revreadlines():
            print eval(s)

if __name__ == '__main__':
    Cat()
