#!/usr/bin/env python
#
"""Explicit usage message
"""

import optparse

parser = optparse.OptionParser(
    usage='%prog [options] <arg1> <arg2> [<arg3>...]',
    version='1.0',
    )

parser.parse_args()
