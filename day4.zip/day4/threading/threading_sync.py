#!/usr/bin/env python
"""Creating and waiting for a thread.
"""
import threading
import random
import time
from os import getpid

class DB(object):
    def __init__(self, s):
        self.s = s

    def doupdate(self):
        with self.s:
            print 'doing update'

class Task(object):
    def __init__(self):
        self.s = threading.Semaphore(1)

    def worker(self, value):
        db = DB(self.s)
        time.sleep(random.randint(1, 2))
        db.doupdate()
        with self.s:
            print 'Worker : {}'.format(value)
        return

threads = []
tsk = Task()

for i in range(5):
    t = threading.Thread(target=tsk.worker, args=(i+1, ))
    t.start()  # starts the excution of the threads 
    threads.append(t)

#for t in threads:
#    t.join()
print 'main thread ends...'





