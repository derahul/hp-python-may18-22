#!/bin/env python 

import threading
import os
import sys
import shutil
from file_split import filesplit, joinfile

def download(name):
    pass
   
file_name = sys.argv[1]

filelist = filesplit(file_name)
    

tlist = []
for fname in filelist:
    t = threading.Thread(name=fname, target=download, args=[fname,])
    t.start()
    tlist.append(t) 
    t.join()   # main thread to wait for the child reads.


while 1:
   if len(threading.enumerate()) == 1: 
	joinfile(filelist, file_name+"__")
        break





