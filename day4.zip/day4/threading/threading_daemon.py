#!/usr/bin/env python
# encoding: utf-8
#
#
"""Daemon vs. non-daemon threads.
"""
#end_pymotw_header

import threading
import time
import random
import logging
import os

print "Current PID : ", os.getpid()

logging.basicConfig(level=logging.DEBUG,
                    format='(%(threadName)-10s) %(message)s',
                    )

def daemon():
    logging.debug('Starting')
    with open('/tmp/filed', 'a') as w:
	while 1:
             w.write(chr(random.randint(1,255)))
 
    #time.sleep(60)
    logging.debug('Exiting')

d = threading.Thread(name='daemon', target=daemon)
#d.setDaemon(True)

def non_daemon():
    logging.debug('Starting')
    logging.debug('Exiting')

t = threading.Thread(name='non-daemon', target=non_daemon)

d.start()
t.start()
d.join()

