#!/usr/bin/env python
"""Creating and waiting for a thread.
"""
import threading
import random
import time
from os import getpid

def worker(value, s):
    time.sleep(random.randint(1, 2))
    with s:
        print 'Worker : {}'.format(value)
    return

threads = []
s = threading.Semaphore(1)

for i in range(5):
    t = threading.Thread(target=worker, args=(i+1, s))
    t.start()  # starts the excution of the threads 
    threads.append(t)

#for t in threads:
#    t.join()
print 'main thread ends...'





