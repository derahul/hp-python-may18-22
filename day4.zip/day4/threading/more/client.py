import socket
import signal
import sys

# Keyboard Interrupt handler and cleanup routine
def cleanup(*args):
    global client_sock

    # Close the client socket
    client_sock.close()
    client_sock = None

    sys.exit(0)

# Catch some signals
signal.signal(signal.SIGINT, cleanup)
signal.signal(signal.SIGTERM, cleanup)

# Require one argument (host to be resolved)
if len(sys.argv) < 2:
    print 'Usage: python %s <domain name>' % sys.argv[0]
    sys.exit(0)

#
# Setup client socket and connect
#
client_sock = socket.socket()
client_sock.connect(('127.0.0.1', 6052))

# Send the domain name to the server
client_sock.send(sys.argv[1])
# Recv the response and print
ip = client_sock.recv(276)
print ip

# Finally, cleanup
cleanup()

