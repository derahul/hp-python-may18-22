#!/usr/bin/env python
import threading
import random
import time

class task(object):
    def worker(self, value):
        time.sleep(random.randint(1, 2))
        print 'Worker thread : {}'.format(value)
        return


threads = []
to = task()

for i in range(5):
    t = threading.Thread(target=to.worker, args=(i,  ))
    t.start() 
    threads.append(t)

for  t in threads:
    t.join()

print "the main thread ends...."
