#!/usr/bin/env python
import threading
import random
import time

def worker(*num):
    """thread worker function"""
    time.sleep(1)
    print 'Worker: %s' % map(str, num)
    return

threads = []
for i in range(5):
    t = threading.Thread(target=worker, args=(i, ), 
		name='t'+str(i))
    t.start()
    threads.append(t)

for t in threads:    
     print t.name
     t.join()




