#!/usr/bin/env python
import logging
import random
import threading
import time

logging.basicConfig(
    level=logging.DEBUG,
    format='%(asctime)s (%(threadName)-2s) %(message)s',
    )

class CheckPrime(object):
    def __init__(self):
        self.content = []

    def getprime(self, sem, startval, endval):   
        for i in range(startval, endval):
            if self.isprime(i):
                with sem:
                    logging.debug('Prime: %s', i)
                    
    def isprime(self, n):    
        startnum =  float(n)
        for divisor in range(2, int(startnum ** 0.5)+1):
            if startnum/divisor == int(startnum/divisor):
                return False
        return True

def main():
  c = CheckPrime()
  s = threading.Semaphore(1)
  start = 1
  max = 250000000
  nooft = 50  
  incr = max/nooft
  end =  incr
  for i in range(nooft):
      
    t = threading.Thread(target=c.getprime,
                         args=(s, start, end ))
    logging.debug('start:{}, end:{} '.format(start, end))
    start += incr
    end +=  incr
    t.start()

if __name__ == '__main__':
    main()






