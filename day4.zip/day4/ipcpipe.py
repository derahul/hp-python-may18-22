#!/usr/bin/env python

import subprocess
cat = subprocess.Popen('cat /etc/passwd', shell=True,
        stdout=subprocess.PIPE)

cut = subprocess.Popen('cut -f 1 -d ":"', shell=True, 
        stdin=cat.stdout, stdout=subprocess.PIPE)

sort = subprocess.Popen('sort', shell=True, 
        stdin=cut.stdout, stdout=subprocess.PIPE)

nl = subprocess.Popen('nl | tee op', shell=True, 
        stdin=sort.stdout, stdout=subprocess.PIPE)

op =  nl.communicate()[0]
print op
