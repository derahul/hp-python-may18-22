#!/usr/bin/env python

import subprocess

op = \
 subprocess.check_output(['/usr/bin/cat', '-n', '/etc/passwd'])

print op.rstrip()

