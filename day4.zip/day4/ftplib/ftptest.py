# Import the FTP object from ftplib
from ftplib import FTP
from getpass import getpass
import os

def handleDownload(block):
    file.write(block)
    print ".",
    
ftp = FTP('16.154.161.14')

print 'Welcome to 16.154.161.14'
print 'Logging in.'
print ftp.login('ravi', getpass('Enter the password :'))
directory = '/home/ravi/Training/Python-Advanced-HP/may18/day4/ftplib'
print 'Changing to ' + directory
ftp.cwd(directory)

filename = 'ftptest0.py'

os.chdir('/tmp')
# Open the file for writing in binary mode
print 'Opening local file ' + filename
file = open(filename, 'wb')

print 'Getting ' + filename
ftp.retrbinary('RETR ' + filename, handleDownload)

# Clean up time
print 'Closing file ' + filename
file.close()

print 'Closing FTP connection'
print ftp.close()
