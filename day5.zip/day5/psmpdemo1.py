__author__ = 'ravi'
import os
import multiprocessing
from time import sleep

def task(delay):
    print "child process : {}".format(os.getpid())
    sleep(delay)

def main():
    proc = []
    for i in range(1, 6):
        p = multiprocessing.Process(target=task, args=(.75,))
        proc.append(p)
        p.start()

    for p in proc:
        p.join()

    print "main process id : {}".format(os.getpid())
    print "main process terminates"

if __name__ == '__main__':
    main()