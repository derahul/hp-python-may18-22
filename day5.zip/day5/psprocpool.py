__author__ = 'ravi'
import multiprocessing
import os
from time import sleep

def task_it(value):
    print "{}: got arg as : {}".format(os.getpid(), value)
    sleep(1)
    return os.getpid(), value ** 2


def main():

    pool = multiprocessing.Pool(processes=3)
    print pool.map(task_it, range(1, 11))

if __name__ == '__main__':
    main()