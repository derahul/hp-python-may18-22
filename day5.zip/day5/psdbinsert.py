__author__ = 'ravi'
# http://www.codegood.com/archives/tag/mysqldb
import MySQLdb
conn = MySQLdb.connect('localhost', 'root', 'password',
                       'may22', autocommit=True)
cur = conn.cursor()

query = 'insert into lang (lang, version)  values (%s, %s)'

data = [('perl', '5.10'), ('pypi', '2.7'), ('ruby', '2.2')]

cur.executemany(query, data)
conn.commit()

cur.close()
conn.close()
