#!/bin/env python 

import logging

logger = logging.getLogger('first')
logger.setLevel(logging.DEBUG)
fh = logging.FileHandler('spam.log')

fmt1 = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
fh.setFormatter(fmt1)
logger.addHandler(fh)

logger2 = logging.getLogger('second')
logger2.setLevel(logging.DEBUG)
fh2 = logging.FileHandler('pampam.log')
logger2.addHandler(fh2)




# 'application' code
logger.debug('debug message1')
logger.info('info message1')

logger2.debug('debug message')
logger2.info('info message')

