__author__ = 'ravi'
import os
import multiprocessing
from time import sleep
import subprocess


def task(read, write):
    cmd = read.recv()
    #cmd = 'dir'
    op = subprocess.check_output(cmd, shell=True)
    write.send(op)


def main():
    rd1, wt1 = multiprocessing.Pipe()
    rd2, wt2 = multiprocessing.Pipe()  #parent to write
    p = multiprocessing.Process(target=task, args=(rd2, wt1))
    p.start()
    wt2.send('dir')
    print rd1.recv()

if __name__ == '__main__':
    main()