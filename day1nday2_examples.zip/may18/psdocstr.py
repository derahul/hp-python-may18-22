__author__ = 'ravi'

s = '''
    {}
   2 2
  3 {} 3
   4 4
    5
'''.format('^', 'x')

print '-' * 15
print s.strip('\n')
print '-' * 15
