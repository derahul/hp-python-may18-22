__author__ = 'ravi'


def word_count(text_file):
    wc = {}
    for line in open(text_file):
        for word in line.rstrip().split(' '):
            if word in wc:
                wc[word] += 1
            else:
                wc[word] = 1
    return wc

result = word_count('mesg.txt')

for word in sorted(result):
    print "{} : {}".format(word, result[word])