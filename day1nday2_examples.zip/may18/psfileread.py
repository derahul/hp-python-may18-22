__author__ = 'ravi'

'''
context managers : with
'''
from pprint import  pprint

with open('/etc/resolv.conf') as fp:
   print fp.readlines()[2]
    #for line in fp:
    #    print line.rstrip()

