__author__ = 'ravi'


def my_zip(seq1, seq2):
    temp = []
    len_seq = len(seq1) if len(seq1) < len(seq2) else len(seq2)

    for i in range(len_seq):
        temp.append((seq1[i], seq2[i]))

    return temp


names = ['larry', 'matz', 'guido']
langs = ['perl', 'ruby']
print my_zip(names, langs)