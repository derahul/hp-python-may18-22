__author__ = 'ravi'
from pprint import pprint

names = ['larry', 'matz', 'guido']
langs = ['perl', 'ruby', 'pypi']
version = [5.20, 2.2, 5.2]

pprint(zip(names, langs, version), width=32)


for n, l, v in zip(names, langs, version):
    print "{:>16} {:>12} {:>8}".format(n, l, v)
