__author__ = 'ravi'


def swap_me(item1, item2):
    return item2, item1

t = swap_me(10, 'pypi')
a, b = swap_me(10, 'pypi')

print a, b
print t

l = list(t)
l[-1] = 'ten'
print tuple(l)