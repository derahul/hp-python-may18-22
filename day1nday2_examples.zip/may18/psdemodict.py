__author__ = 'ravi'

info = {'name': 'python',
        'version': 2.7,
        'author': 'guido', 'category': 'script'}

print info
print len(info)
print type(info)
