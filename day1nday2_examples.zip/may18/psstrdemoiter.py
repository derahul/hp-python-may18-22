__author__ = 'ravi'

s = 'pypi'
i = 1

for item in s:
    print item * i
    i += 1

