__author__ = 'ravi'
from sys import argv

print argv
