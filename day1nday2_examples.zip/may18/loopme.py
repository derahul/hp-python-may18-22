__author__ = 'ravi'


def loopme(start, end):
    while start <= end:
        if start == 4:
            break
        elif start == 1:
            print 'one'
        elif start == 2:
            start += 1
            continue
        else:
            print start
        start += 1

loopme(1, 5)