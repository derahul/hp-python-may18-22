from sys import argv


def usage():
    print "{} source-file dest-file".format(argv[0])
    exit(1)


def copy(source, dest):
    with open(dest, 'wb') as fw:
        fw.write(open(source, 'rb').read())

if len(argv) != 3:
    usage()
    
copy(argv[1], argv[2])        
