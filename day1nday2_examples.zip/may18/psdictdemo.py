__author__ = 'ravi'

data = [('category', 'script'), ('platform', 'linux2'),
    ('version', 2.7), ('name', 'python'), ('author', 'guido')]


info = dict(data)
info['name'] = 'perl'

print info['category']
print info['name']
print info['version']
print info.get('author')
print info.get('authorr')
print info.get('authorr', 'unknown-key')

'''
for item in sorted(info):
    print "[{}] -> {}".format(item, info[item])
'''