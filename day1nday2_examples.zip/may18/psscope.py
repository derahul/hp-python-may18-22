__author__ = 'ravi'
'''
scope
  -local
  -global
'''
n = 12  #lives in the global scope

def demo():
    global n
    n = 'pypi'
    print n

demo()
print n