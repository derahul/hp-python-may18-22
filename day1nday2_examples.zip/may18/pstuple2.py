__author__ = 'ravi'

items = 'nelson', 'male', 'manager', 'sales'
print items


t = (1000, )
print t