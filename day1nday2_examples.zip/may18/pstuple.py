__author__ = 'ravi'

t = (1, 2, 'three', 4.0, 5.5)

t[-3] = 3

print t
'''
print len(t)
print type(t)
'''