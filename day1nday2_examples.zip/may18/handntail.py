__author__ = 'ravi'


def headntail(file_name, **param):
    count = param.get('count', 10)
    order = param.get('order', 'head')

    content = open(file_name).readlines()

    if order == 'head':
        temp = content[:count]
    elif order == 'tail':
        temp = content[-count:]

    return ''.join(temp).rstrip()

print headntail('/etc/passwd', count=3, order='tail')

