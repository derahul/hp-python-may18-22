__author__ = 'ravi'

l = [1, 2.2, 'three', 4, 5]
l[-3] = 3

l.append('pypi')
l.insert(0, 'hp')

print l

