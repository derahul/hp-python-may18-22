__author__ = 'ravi'
from pprint import pprint

info = {'name': 'python',
        'version': 2.7,
        'author': 'guido', 'category': 'script'}

info['platform'] = 'linux2'

print info.keys()
print info.values()
print info.items()