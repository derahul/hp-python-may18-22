__author__ = 'ravi'
a, b = 10, 'peter'
a, b = b, a

print a
print b

exit(1)



#parallel assignment
(host, doamin, app) = ('ws1', 'rc.in', 'ws')
t = 'ws1', 'rc.in', 'ws'
print t
'''
print host
print doamin
print app
'''
s = 'v4001,ravi,8712389012,bangalore'
visitor_id, name, mobile, city = s.split(',')

print visitor_id
print city