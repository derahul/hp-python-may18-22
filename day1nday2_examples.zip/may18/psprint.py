__author__ = 'ravi'

print 'kim',
print 'eva',
print 'tim',
print 'tom',
print 'jane'

print 1,2,'three',4.5
