__author__ = 'ravi'

print bool(0)
print bool(0L)
print bool(0.0)
print bool(0+0j)

print bool('')

print bool([])
print bool(())  #empty tuple
print bool({})

print bool(None)