__author__ = 'ravi'

l = [1, 2.2, 'three', 4, 5]
print l
print len(l)
print type(l)
