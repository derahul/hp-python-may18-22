__author__ = 'ravi'


def get_user_list(user_file):
    temp = []
    with open(user_file) as fp:
        for line in fp:
            user_name = line.split(':')[0].upper()
            temp.append(user_name)
    return temp

user_list = sorted(get_user_list('/etc/passwd'))

with open('user_list.dat', 'w') as fw:
    for i, user in enumerate(user_list, 1):
        content = "{:>6}  {}".format(i, user)
        fw.write(content + "\n")
        print content