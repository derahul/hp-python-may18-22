__author__ = 'ravi'

path = 'c:\temp\nancy\templates\files1.txt'
print path

print

path = r'c:\temp\nancy\templates\files1.txt'
print path


