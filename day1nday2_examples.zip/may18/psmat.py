__author__ = 'ravi'

mat = [[1, 2, 3],
       [4, 5, 6, 10],
       [7, 8, 9]]

print [c for r in mat if len(r) == 3 for c in r if c%2]
'''
col2 = []
for r in mat:
    col2.append(r[1])

print col2

print [row[1] for row in mat]
'''