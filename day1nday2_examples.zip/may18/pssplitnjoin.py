__author__ = 'ravi'

s = 'root:x:0:0:root:/root:/bin/bash'

l = s.split(':')

print l
print s.split(':')[0]
print s.split(':')[1:]
print

s2 = ','.join(l)
print s2
