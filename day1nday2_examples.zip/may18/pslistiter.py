__author__ = 'ravi'

l = [2,1,5,4,6]

temp = []
for item in l:
    temp.append(item ** item)

print temp

temp2 = [ i ** i for i in l]
print temp2
