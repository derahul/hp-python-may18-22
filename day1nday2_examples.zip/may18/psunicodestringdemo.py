# -*- coding:utf-8 -*-

s = ur'this\tist\na sample'
print s