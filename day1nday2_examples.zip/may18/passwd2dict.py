__author__ = 'ravi'
from pprint import pprint


content = {l.split(':')[0]: l.rstrip().split(':')[1:]
                                for l in open('/etc/passwd')}

for login in content:
    print login
    for item in content[login]:
        print "{:>6} {:<46}".format('', item)
    print
'''
for login in content:
    print "{}:{}".format(login, content[login][-1])
'''