__author__ = 'ravi'

'''
syntax
lambda args1,arg2,...: code-block
'''
power = lambda x, n=0: x ** n

print power(2)


raiseme = lambda n:  n ** 2 if n > 5 else n ** 3
print raiseme(5)
