__author__ = 'ravi'
'''
tags = ['login', 'password']
vals = ['root', 'x']

print dict(zip(tags, vals))
'''
from pprint import pprint

tags = ['login', 'password', 'uid', 'gid', 'gecos', 'home', 'shell']

content = [dict(zip(tags, l.rstrip().split(':')))
                        for l in open('/etc/passwd')]
pprint(content)