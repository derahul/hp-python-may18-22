__author__ = 'ravi'

lang = 'python'
author = 'rossum'
version = 2.7

print "|{}|{}|{}|".format(lang, version, author)
print "|{:>16}|{:>8.2f}|{:>16}|".format(lang, version, author)
print "|{:<16}|{:<8.2f}|{:<16}|".format(lang, version, author)
print "|{:^16}|{:^8.2f}|{:^16}|".format(lang, version, author)
print "|{:16}|{:8.2f}|{:16}|".format(lang, version, author)

