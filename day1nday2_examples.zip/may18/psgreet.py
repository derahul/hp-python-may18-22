__author__ = 'ravi'

name = 'hp'
city = 'bangalore'

print 'name :', name
print 'city :', city
