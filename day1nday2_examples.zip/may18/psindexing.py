__author__ = 'ravi'
s = 'python'

print s[-print s[:]1]
print s[len(s)-2]
print s[-3]
print s[-4]
print s[-5]
print s[-6]
