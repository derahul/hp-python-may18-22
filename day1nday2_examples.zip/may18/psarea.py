__author__ = 'ravi'
from math import pi

radius = float(raw_input('Enter the radius :'))
area = pi * (radius ** 2)

'''
string formatting
'''

result = "radius : %s\narea : %.3f" % (radius, area)
print result.upper()
