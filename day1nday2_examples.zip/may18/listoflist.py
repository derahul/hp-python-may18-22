__author__ = 'ravi'
from pprint import  pprint

content = [l.rstrip().split(':') for l in open('/etc/passwd')]

pprint(content)
