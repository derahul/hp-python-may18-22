__author__ = 'ravi'
from decimal import Decimal as D

a = 0.1
b = 0.3

result = D(str(a)) + D(str(a)) + D(str(a)) - D(str(b))
print result


print D(a)
print D(str(a))