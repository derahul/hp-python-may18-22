__author__ = 'ravi'

counter = 0

def demo():
    global counter
    counter += 1

demo()
demo()
demo()

print counter
