__author__ = 'ravi'

l = [1, 2.2, 'three', 4, 5]
'''
value = l.pop()
print value
print l
'''
value = l.pop(0)
print value

l.remove('three')
print l

