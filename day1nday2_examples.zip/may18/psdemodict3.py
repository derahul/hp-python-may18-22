__author__ = 'ravi'
from pprint import pprint

info = {'name': 'python',
        'version': 2.7,
        'author': 'guido', 'category': 'script'}

info['platform'] = 'linux2'

del info['name']

value = info.pop('category')
print value

pprint(info)

