__author__ = 'ravi'
from pprint import pprint
n = 12.12

def demo():
    n = 'pypi'
    print locals()

demo()
pprint(globals())