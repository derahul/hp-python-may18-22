__author__ = 'ravi'

def demo(*args):
    print args
'''
demo()
demo(123)
demo('larry', 1,2,3,4)
'''
t = ('a', 2, 'b', 3)
demo(*t)
l = [1,2,3,4]
demo(*l)
