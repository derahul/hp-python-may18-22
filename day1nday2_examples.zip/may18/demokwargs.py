__author__ = 'ravi'

def demo(**args):
    print args


demo()
demo(name='peter', lname='pan', category='comic')

info = {'lname': 'pan', 'category': 'comic', 'name': 'peter'}
demo(**info)