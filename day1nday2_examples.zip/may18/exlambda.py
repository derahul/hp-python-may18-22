__author__ = 'ravi'

def getdivby7(n):
    return n%7==0

l = range(1, 33)
divby7 = filter(lambda n: n%7==0, l)
print filter(getdivby7, l)

print lambda n: "<bin>{}</bin>".format(bin(n)), divby7

