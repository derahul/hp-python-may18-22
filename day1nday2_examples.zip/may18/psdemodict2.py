__author__ = 'ravi'
from pprint import pprint

info = {'name': 'python',
        'version': 2.7,
        'author': 'guido', 'category': 'script'}

info['platform'] = 'linux2'

key = 'version'

if key in info:
    info[key] = 3.3

print help(info.viewvalues())

