__author__ = 'ravi'

s = 'pypi'

for temp in s:
    if temp == 'y':
        break
    print "{} -> {}".format(temp, ord(temp))
    print "-" * 10

print "out of the code block"

