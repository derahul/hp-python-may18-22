__author__ = 'ravi'


def center(string_content, width, fill=' '):
    n = (width - len(string_content)) / 2
    return "{}{}{}".format(fill * n, string_content, fill * n)

print center('perl', 8,'-')
print '''.center(8, '-')
