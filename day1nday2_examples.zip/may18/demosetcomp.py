__author__ = 'ravi'

from pprint import pprint

users = {l.rstrip().split(':')[0] for l in open('/etc/passwd')}
group = {l.rstrip().split(':')[0] for l in open('/etc/group')}
'''
pprint(users - group)
pprint(group-users)
'''
pprint(users.intersection(group))