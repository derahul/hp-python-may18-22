__author__ = 'ravi'
import datetime

dt = datetime.datetime(2014, 06, 04, 9, 30)
print dir(dt.today() - dt)

print dt.ctime()
