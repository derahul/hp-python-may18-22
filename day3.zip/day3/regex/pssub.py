__author__ = 'ravi'
import re
match_counter = 0

def fixit(m):
    global match_counter
    match_counter += 1
    return '*' if match_counter == 3 else m.groups()[0]

s = 'this is sample string'

print re.sub('([AEIOU])', fixit, s, flags=re.I)
