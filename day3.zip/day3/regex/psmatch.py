__author__ = 'ravi'
import re

s = 'the python scripting'
m = re.match('Python', s, re.IGNORECASE)

if m:
    print m
    print 'got a match'
else:
    print "fails to match :("