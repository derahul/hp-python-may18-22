__author__ = 'ravi'
import re

s = 'the python scripting'
m = re.search('Python', s, re.IGNORECASE)

if m:
    print "matched : {}".format(m.group())
    print m.start()
    print m.end()
    print m.span()

else:
    print "fails to match :("