__author__ = 'ravi'
from fileinput import input
import re

for line in input(inplace=True, backup='.bak'):
    print re.sub(r'(\d+)', r'[\1]', line).rstrip()
