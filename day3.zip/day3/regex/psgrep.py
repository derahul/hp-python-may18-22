__author__ = 'ravi'
import re
import fileinput
from sys import argv


class GrepMe(object):
    def __init__(self, pattern):
        self.pattern = pattern

        for line in fileinput.input():
            if re.search(self.pattern, line):
                print line.rstrip()


def main():
    GrepMe(argv.pop(1))

if __name__ == '__main__':
    main()

