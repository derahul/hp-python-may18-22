import re
import fileinput
'''
pattern='([1-9]|[1-9][0-9]|1[0-9][0-9]|2[0-4][0-9]|25[0-4])'
'''

pattern=r'([1-9]|[1-9][0-9]|1[0-9][0-9]|2[0-4][0-9]|25[0-4])(\.([0-9]|[1-9][0-9]|1[0-9][0-9]|2[0-4][0-9]|25[0-4])){3}'

print pattern

for line in fileinput.input():
    if re.search(pattern, line):
	    print line.rstrip()

