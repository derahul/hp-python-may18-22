__author__ = 'ravi'

import subprocess

subprocess.call('dir', shell=True)

#op = subprocess.check_output('dir', shell=True)
#print op
