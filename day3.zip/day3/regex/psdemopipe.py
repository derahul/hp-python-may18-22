__author__ = 'ravi'

import subprocess

cat = subprocess.Popen('cat /etc/passwd', shell=True,
                       stdout=subprocess.PIPE)

cut = subprocess.Popen("cut -f 1 -d ':'", shell=True,
                       stdout=subprocess.PIPE, stdin=cat.stdout)

sort = subprocess.Popen('sort', shell=True,
                       stdout=subprocess.PIPE, stdin=cut.stdout)

nl = subprocess.Popen('python psnl.py', shell=True,
                       stdout=subprocess.PIPE, stdin=sort.stdout)

for line in nl.communicate():
    if line:
        print line.rstrip()


