__author__ = 'ravi'

class Demo(object):
    def __init__(self):
        print self, "am in constructor"

    def __del__(self):
        print '{}: getting destoryed'.format(self)

d = Demo()
print d
