__author__ = 'ravi'
from pprint import pprint
from sys import argv
from os import listdir, stat
from os.path import isfile, join


class DirectoryListing(object):
    def __init__(self, directory_name):
        self.directory_name = directory_name
        self.container = {}
        self.__do_listing()

    def __do_listing(self):
        temp = {}

        for file_name in listdir(self.directory_name):
            abs_path = join(self.directory_name, file_name)
            if isfile(abs_path):
                temp[file_name] = stat(abs_path).st_size

        self.container[self.directory_name] = temp

def main():
    d = DirectoryListing(argv[1])
    pprint(d.container)

if __name__ == '__main__':
    main()