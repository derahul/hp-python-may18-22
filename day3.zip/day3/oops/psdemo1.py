__author__ = 'ravi'

class Demo(object):
    pass


d = Demo()  #instance
print __name__  #name of the current namespace
print Demo
print d
