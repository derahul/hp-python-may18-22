__author__ = 'ravi'

from psperson import Person


class Employee(Person):
    def __init__(self, eid, first_name, last_name, gender, desg):
        self.eid = eid
        self.desg = desg
        '''
        the below line is responsible for calling the base class
        version if __init__()
        '''
        super(Employee, self).__init__(first_name, last_name, gender)

    def get_info(self):
        print "employee id : {}".format(self.eid)
        super(Employee, self).get_info()
        print "designation : {}".format(self.desg)


def main():
    e = Employee('v4002', 'guido', 'rossum', 'male', 'clerk')
    e.get_info()

if __name__ == '__main__':
    main()