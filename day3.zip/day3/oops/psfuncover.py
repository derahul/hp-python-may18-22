__author__ = 'ravi'

def demo():
    print "null arg function"


def demo(a, b):
    print a + b

'''
print demo
print type(demo)
'''
demo(2,2)
