__author__ = 'ravi'
from sys import argv


class ConnectionPool(object):
    Max_Connection = 5
    counter = 0

    def __init__(self, connection_id):
        ConnectionPool.counter += 1
        ConnectionPool.check_connection(123)
        self.connection_id = connection_id

    @staticmethod
    def check_connection(self):
        print self
        if ConnectionPool.counter > ConnectionPool.Max_Connection:
            raise RuntimeError('{}: reached max allowed connections'.
                            format(argv[0]))

    '''print check_connection
    check_connection = staticmethod(check_connection)
    print check_connection
    exit(1)'''

c = ConnectionPool(100)
c.check_connection(100)
ConnectionPool.check_connection('pam pam')
exit(1)
def main():
    for cid in range(1, 10):
        print ConnectionPool(cid)

if __name__ == '__main__':
    main()