__author__ = 'ravi'
import fileinput

class Utils(object):
    def nl(self):
        for line in fileinput.input():
            print "{:>6}  {}".format(fileinput.lineno(), line.rstrip())

if __name__ == '__main__':
    Utils().nl()
