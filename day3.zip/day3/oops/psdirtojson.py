__author__ = 'ravi'
from psdirlisting import DirectoryListing
from json import dump
from sys import argv, stderr


class Directory2JSON(DirectoryListing):
    def __init__(self, directory_name, json_file):
        self.json_file = json_file
        super(Directory2JSON, self).__init__(directory_name)

    def to_json(self):
        with open(self.json_file, 'w') as fw:
            dump(self.container, fw, indent=4)


def usage():
    print >>stderr, "{} directory-name json-file".format(argv[0])
    exit(1)


def main():
    if len(argv) != 3:
        usage()
    d = Directory2JSON(argv[1], argv[2])
    d.to_json()

if __name__ == '__main__':
    main()
