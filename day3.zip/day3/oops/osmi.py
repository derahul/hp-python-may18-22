__author__ = 'ravi'
class Zero(object):
    def pprint(self):
        print "pprint from the class Zero"

class A(Zero):
    def pprint(self):
        print "pprint from the class A"


class B(object):
    pass

class C(B, A):
    def pprint(self):
        super(C, self).pprint()
        #A.pprint(self)
        #B.pprint(self)

if __name__ == '__main__':
    c = C()
    c.pprint()
