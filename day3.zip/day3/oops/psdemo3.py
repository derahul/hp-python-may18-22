__author__ = 'ravi'

class Demo(object):
    def __init__(self, data):
        self.__data = data

    def __get_data(self):
        return self.__data

    def __del__(self):
        print '{}: getting destoryed'.format(self)

d = Demo('pypi')
print d.__get_data()
#print d.__data
